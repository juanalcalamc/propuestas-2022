<!DOCTYPE html>
<html lang="en">
<?include 'head.php'?>
<body>
<?include 'Presentacion.php'?>

  
<div class="container">
  <div class="row">
    <?include 'columna1.php';
      include 'columna2.php';
    ?> 
  </div>
  <div class="row">
    <?include 'editorial.php'?>
  </div>
</div>
</body>
</html>
  