<div class="col-sm-4">
      <h3>Búsqueda de libros</h3>
     <div>
       <form class="form-group" 
             action="index.php"
             method="post">
         <input type="text" 
           name="campo1" 
           clas="form-group"
           placeholder="Ingrese un criterio de búsqueda">
         <button type="submit" 
           class="btn btn-success form-group">Buscar</button>
       <a href="crear_autor.php"
         class="btn btn-success"
         title="Crear autor">+</a>
         </form>
     </div>
  <div>
        <h3>Búsqueda de editorial</h3>
       <form class="form-group" 
             action="index.php"
             method="post">
         <input type="text" 
           name="campo2" 
           clas="form-group"
           placeholder="Ingrese un criterio de editorial">
         <button type="submit" 
           class="btn btn-success form-group">Buscar editorial</button>
       </form>
     </div>
    </div>