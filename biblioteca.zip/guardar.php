<? 

$nombrel=$_POST['nombreL'];
$nombre=$_POST['nombreE'];
$tipo=$_POST['tipo'];

include 'config/conexion.php';
if(empty($nombre) || empty($fecha))
{
echo '<br>Los campos Marcados con (*) son obligatorios';
} else{
include 'config/conexion.php';
if(!$con){
 die("Error en la conexión");
 }
$sql ="INSERT INTO tblautores(nombreL,nombreE)values('$nombre','$telefono')";
echo '<br>'.$sql;
$consulta = mysqli_query($con,$sql)
or die("Fallo en la inserción".mysqli_error($con));
mysqli_close($con);
}

?>