<?


include 'config/conexion.php';


?>
<!DOCTYPE html>
<html lang="en">
<?include 'head.php'?>
<body>
<?include 'Presentacion.php'?>

<div class="container">
  <h2> Autores || <a href="index.php">
    Regresar</a> </h2>
  <div class="row">
  <div class="col">
  <form action="guardar.php" method="POST">
   <input type="text" 
          name="nombreL" 
          maxlength="30"
          class="form control"
          placeholder="nombreE"
          title="Name autor, your length max of field is 30">
    <label for="fecha">birth date</label>
    <input type="date" name="fecha">
    <select name="tipo">
     <option value="cuento">Cuento</option>
       <option value="romance">Romance </option>
       <option value="terror">Terror </option>
      <option value="fision">fision </option>
      
    </select>
    <input type="text" name="cons">
    <button type=="submit">Save</button>
  </form>
    
  </div>  
   <div class="col">
     Listado de autores
     <?
     $sql="SELECT nombreL,nombreE,tipo, codigo FROM tblautores";
     $registro=mysqli_query($con,$sql) or die('Error en sql'.$sql);
  echo '<table><tr><td>nombre libro</td><td>nombre escritor</td><td>tipo libro</td><td>cons</td></tr>';
  while($r=mysqli_fetch_array($registro)){
    echo "<tr><td>" .$r['nombreL']. "</td><td>" .$r['nombreE'].  "</td><td>" .$r['tipo'].  "</td><td>" .$r['cons'].  "</td>
     </tr>";
  }
  mysqli_close($con);
    ?>
  </div>  
  </div>

</div>
</body>
</html>
