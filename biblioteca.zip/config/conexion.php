<?
$host="btgp6kwtqiarccp7se9i-mysql.services.clever-cloud.com";
$bd="btgp6kwtqiarccp7se9i";
$user="ubnl7veryfodvcto";
$pwd="6jGtfjqaTfnzkAWVpPLG";
$con=mysqli_connect($host,$user,$pwd,$bd) or
    die(" Problemas en la conexión");
?>